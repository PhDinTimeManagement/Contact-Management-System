import json
import re

FILE_NAME = "contacts.txt"


class Contact:
    """
    Represents a contact.
    """

    def __init__(self, name, phone, email, rel="", org="", loc=""):
        """
        Initializes a contact.
        :param name:
        :param phone:
        :param email:
        :param rel:
        :param org:
        :param loc:
        """
        self.name = None
        self.phone = None
        self.email = None
        self.rel = None
        self.org = None
        self.loc = None
        self.set_attributes(name, phone, email, rel, org, loc)

    def set_attributes(self, name, phone, email, rel="", org="", loc=""):
        """
        Sets the attributes of a contact.
        If the name or phone number is empty, it raises a ValueError.
        :param name:
        :param phone:
        :param email:
        :param rel:
        :param org:
        :param loc:
        :return:
        """
        if not name or not phone:
            raise ValueError("Error: Both 'Name' and 'Phone Number' are required fields.")
        self.name = name
        self.phone = phone
        self.email = email
        self.rel = rel
        self.org = org
        self.loc = loc

    def __str__(self):
        """
        Returns a string representation of a contact.
        """
        string = f"Name: {self.name}\nPhone: {self.phone}"
        if self.email:
            string += "\nEmail: " + self.email
        if self.rel:
            string += "\nRelationship: " + self.rel
        if self.org:
            string += "\nOrganization: " + self.org
        if self.loc:
            string += "\nLocation: " + self.loc
        return string

    def to_dict(self):
        """
        Returns a dictionary representation of a contact.
        :return:
        """
        return {
            "name": self.name,
            "phone": self.phone,
            "email": self.email,
            "rel": self.rel,
            "org": self.org,
            "loc": self.loc,
        }


def read_file(filename):
    """
    Reads the contacts data from a file.
    If the file does not exist, it returns an empty list.
    If the file is empty, it returns an empty list.
    If the file contains invalid data, it returns an empty list.
    :param filename:
    :return:
    """
    try:
        with open(filename, "r", encoding="utf-8") as file:
            contacts = []
            for line in file:
                data = json.loads(line)
                contact = Contact(**data)
                contacts.append(contact)
            return contacts
    except FileNotFoundError:
        print(f"The file {filename} was not found.")
        return []


def save_file(filename, contacts):
    """
    Saves the contacts data to a file.
    :param filename:
    :param contacts:
    :return:
    """
    try:
        with open(filename, "w", encoding="utf-8") as file:
            for contact in contacts:
                file.write(json.dumps(contact.to_dict()) + "\n")
    except IOError as e:
        print(f"Failed to save contacts to {filename}: {e.strerror}")


def get_user_input(prompt, is_required=False):
    """
    Obtains user input based on a given prompt.
    If the input is required, the user will be prompted to enter a value
    :param prompt:
    :param is_required:
    :return:
    """
    while True:
        user_input = input(prompt).strip()
        if len(user_input) > 0 or not is_required:
            return user_input
        else:
            print("\nInvalid input. Please try again.")


def get_user_input_boolean(prompt):
    """
    Obtains user input based on a given prompt. The user will be prompted to enter a value
    :param prompt:
    :return:
    """
    while True:
        user_input = get_user_input(prompt, True).lower()
        if user_input == "y":
            return True
        elif user_input == "n":
            return False
        else:
            print("\nInvalid input. Please try again.")


def get_user_input_keyword():
    """
    Obtains user input based on a given prompt.
    The user will be prompted to enter a value
    :return:
    """
    return get_user_input("\nPlease enter keyword: ")


def get_user_input_contact():
    """
    Obtains user input based on a given prompt.
    The user will be prompted to enter a value for each field.
    :return:
    """
    while True:
        phone = input("Phone Number (Required): ")
        if phone.isdigit():
            break
        print("Invalid phone number. It should only contain digits.")

    email_pattern = r'^[a-zA-Z0-9.-_]+@[a-zA-Z0-9.-_]+\.[a-zA-Z]+$'
    while True:
        email = input("Email Address (Optional): ")
        if not email or re.match(email_pattern, email):
            break
        print("Invalid email. Please enter a valid email address\n"
              "\t\t\t   E.g.[char.-_digit]@[char.-_digit].[char]")

    rel = input("Relationship Type: (Optional): ")
    org = input("Organization Name (Optional): ")
    loc = input("Location: (Optional): ")

    return {
        "phone": phone,
        "email": email,
        "rel": rel,
        "org": org,
        "loc": loc
    }


def display_contacts(contacts):
    """
    Displays the contacts in a visually appealing way.
    :param contacts:
    :return:
    """
    if not contacts:
        print("\nNo Contact")
        return
    print()
    print("-" * 30)
    print(f"The Total No. of Contacts: {len(contacts)}")
    for contact in contacts:
        print("-" * 30)
        print(contact)
        print("-" * 30)


def add_contact(contacts):
    """
    Adds a new contact to the contact list.
    The user is prompted to enter the name of the contact they wish to add.
    If a contact with the same name already exists, the user is prompted to modify it.
    Otherwise, a new contact is added.
    :param contacts:
    :return:
    """
    try:
        name = get_user_input("\nName (Required): ", True)
        same_name_contacts = filter_contacts(contacts, "name", name, True)
        if same_name_contacts:
            is_modify = get_user_input_boolean("A contact with the same name exists.\n"
                                               "Would you want to modify it? (Y/N): ")
            if is_modify:
                contact_dict = get_user_input_contact()
                contact = same_name_contacts[0]
                contact.set_attributes(name, **contact_dict)
                print("Contact modified successfully.")
        else:
            contact_dict = get_user_input_contact()
            contact = Contact(name, **contact_dict)
            contacts.append(contact)
            print("Contact added successfully.")
    except ValueError as e:
        print(f"Error: {e}")


def modify_contact(contacts):
    """
    Modifies an existing contact in the contact list.
    The user is prompted to enter the name of the contact they wish to modify.
    If a contact with the same name exists, the user is prompted to modify it.
    Otherwise, the user is informed that the contact does not exist.
    :param contacts:
    :return:
    """
    try:
        name = get_user_input("\nName (Required): ", True)
        same_name_contacts = filter_contacts(contacts, "name", name, True)
        if not same_name_contacts:
            print("Contact not found.")
            return
        contact = same_name_contacts[0]
        contact_dict = get_user_input_contact()
        contact.set_attributes(name, **contact_dict)
        print("Contact modified successfully.")
    except ValueError as e:
        print(f"Error: {e}")


def remove_contact(contacts):
    """
    Removes an existing contact from the contact list.
    The user is prompted to enter the name of the contact they wish to remove.
    If a contact with the same name exists, it is removed.
    Otherwise, the user is informed that the contact does not exist.
    :param contacts:
    :return:
    """
    try:
        name = get_user_input("\nName (Required): ", True)
        same_name_contacts = filter_contacts(contacts, "name", name, True)
        if not same_name_contacts:
            print("Contact not found.")
            return
        contact = same_name_contacts[0]
        contacts.remove(contact)
        print("Contact removed successfully.")
    except ValueError as e:
        print(f"Error: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")


def display_user_manual():
    """
    Displays the user manual.
    :return:
    """
    print("""
    =================================================================
    User Manual for Contact Management System
    1. List All Contacts
        View the complete list of your contacts.
    2. Add New Contact
        Enter details for a new contact line by line with guidance.
    3. Modify Contact
        Update details for an existing contact by entering their name.
    4. Remove Contact
        Erase a contact from your list using their name.
    5. Search by Relationship (case-insensitive)
        Find contacts by specifying their exact relationship type.
    6. Search by Organization (case-insensitive)
        Locate contacts by entering their exact organization name.
    7. Search by Location (case-insensitive)
        Search for contacts based on their specific location.
    8. Fuzzy Search (case-insensitive)
        Use partial information to search across all contact fields.
    9. Quit
        Save all changes and close the program.
    =================================================================
                    Now you can choose the option.
    """)


def filter_contacts(contacts, field, keyword, is_fully_match):
    """
    Filters the contacts based on the given field and keyword.
    If the field is None, the keyword will be searched in all fields.
    If the is_fully_match is True, the keyword will be matched exactly.
    If the is_fully_match is False, the keyword will be matched partially.
    The keyword matching is case-insensitive.
    :param contacts:
    :param field:
    :param keyword:
    :param is_fully_match:
    :return:
    """
    result = []
    if not contacts:
        return result
    keyword = keyword.strip().lower()
    # Global search across all fields if 'field' is None
    if field is None:
        for contact in contacts:
            contact_dict = contact.to_dict()
            if re.match(f".*{keyword}.*", str(contact_dict).lower()):
                result.append(contact)
    else:
        # Field-specific search
        for contact in contacts:
            contact_dict = contact.to_dict()
            field_value = str(contact_dict[field]).lower()
            if is_fully_match and keyword == field_value \
                    or not is_fully_match and keyword in contact_dict[field]:
                result.append(contact)
    return result


def get_menu_selection():
    """
    Displays the menu and obtains the user's selection.
    :return:
    """
    menu = """
    =============================================
                CONTACT MANAGER SYSTEM
    =============================================
    Please select an option by entering a number:

    0. Display User Manual
    1. List All Contacts
    2. Add New Contact
    3. Modify Contact
    4. Remove Contact
    5. Search by Relationship
    6. Search by Organization
    7. Search by Location
    8. Fuzzy Search
    9. Quit

    Enter your choice (0-9): """

    return input(menu)


def cms_cli():
    """
    The main function of the program.
    It displays the menu and handles the user's input.
    :return:
    """
    contacts = read_file(FILE_NAME)
    try:
        while True:
            choice = get_menu_selection()
            if choice == "0":
                display_user_manual()
            elif choice == "1":
                display_contacts(contacts)
            elif choice == "2":
                add_contact(contacts)
            elif choice == "3":
                modify_contact(contacts)
            elif choice == "4":
                remove_contact(contacts)
            elif choice == "5":
                result = filter_contacts(contacts, "rel", get_user_input_keyword(), True)
                display_contacts(result)
            elif choice == "6":
                result = filter_contacts(contacts, "org", get_user_input_keyword(), True)
                display_contacts(result)
            elif choice == "7":
                result = filter_contacts(contacts, "loc", get_user_input_keyword(), True)
                display_contacts(result)
            elif choice == "8":
                result = filter_contacts(contacts, None, get_user_input_keyword(), False)
                display_contacts(result)
            elif choice == "9":
                save_file(FILE_NAME, contacts)
                print("\nChanges saved.")
                break
            else:
                print("\nInvalid input. Please try again.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
    finally:
        print("\nQuitting...\nBye~")


if __name__ == '__main__':
    cms_cli()
