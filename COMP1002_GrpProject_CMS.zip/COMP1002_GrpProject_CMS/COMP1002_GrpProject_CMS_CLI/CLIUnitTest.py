import unittest
from unittest.mock import mock_open, patch
import json
import cms_cli


class TestCMSCLI(unittest.TestCase):
    def setUp(self):
        self.contacts = [
            cms_cli.Contact("John Doe", "1234567890", "john@example.com", "Friend", "Company A", "City A"),
            cms_cli.Contact("Jane Smith", "9876543210", "jane@example.com", "Colleague", "Company B", "City B"),
        ]

    def test_read_file(self):
        with patch('builtins.open', mock_open(read_data='{"name": "John Doe", "phone": "1234567890", "email": "john@example.com", "rel": "Friend", "org": "Company A", "loc": "City A"}\n{"name": "Jane Smith", "phone": "9876543210", "email": "jane@example.com", "rel": "Colleague", "org": "Company B", "loc": "City B"}')):
            contacts = cms_cli.read_file("contacts.txt")
            self.assertEqual(len(contacts), 2)
            self.assertEqual(contacts[0].name, "John Doe")
            self.assertEqual(contacts[1].name, "Jane Smith")

    def test_save_file(self):
        mock_file = mock_open()
        with patch('builtins.open', mock_file) as mock_open_file:
            cms_cli.save_file("test_contacts.txt", self.contacts)
            mock_open_file.assert_called_once_with("test_contacts.txt", "w", encoding="utf-8")
            expected_data = json.dumps(self.contacts[0].to_dict()) + "\n" + json.dumps(self.contacts[1].to_dict()) + "\n"
            mock_file.return_value.write.assert_called()
            self.assertEqual(mock_file.return_value.write.call_count, 2)

    def test_get_user_input(self):
        with patch('builtins.input', return_value="John"):
            user_input = cms_cli.get_user_input("Enter your name: ")
            self.assertEqual(user_input, "John")

    def test_get_user_input_boolean(self):
        with patch('builtins.input', return_value="Y"):
            user_input = cms_cli.get_user_input_boolean("Do you want to continue? (Y/N): ")
            self.assertTrue(user_input)
        with patch('builtins.input', return_value="N"):
            user_input = cms_cli.get_user_input_boolean("Do you want to continue? (Y/N): ")
            self.assertFalse(user_input)

    def test_get_user_input_keyword(self):
        with patch('builtins.input', return_value="Friend"):
            user_input = cms_cli.get_user_input_keyword()
            self.assertEqual(user_input, "Friend")

    def test_get_user_input_contact(self):
        with patch('builtins.input', side_effect=["1234567890", "john@example.com", "Friend", "Company A", "City A"]):
            contact = cms_cli.get_user_input_contact()
            self.assertEqual(contact["phone"], "1234567890")
            self.assertEqual(contact["email"], "john@example.com")
            self.assertEqual(contact["rel"], "Friend")
            self.assertEqual(contact["org"], "Company A")
            self.assertEqual(contact["loc"], "City A")

    def test_filter_contacts(self):
        filtered_contacts = cms_cli.filter_contacts(self.contacts, "rel", "Friend", True)
        self.assertEqual(len(filtered_contacts), 1)
        self.assertEqual(filtered_contacts[0].name, "John Doe")

        filtered_contacts = cms_cli.filter_contacts(self.contacts, None, "john", False)
        self.assertEqual(len(filtered_contacts), 1)
        self.assertEqual(filtered_contacts[0].name, "John Doe")


if __name__ == '__main__':
    unittest.main()