import json
import re
import tkinter as tk
from tkinter import messagebox

FILE_NAME = "contacts.txt"


class Contact:

    def __init__(self, name, phone, email, rel="", org="", loc=""):
        """
        Initializes a contact.
        :param name:
        :param phone:
        :param email:
        :param rel:
        :param org:
        :param loc:
        """
        self.name = None
        self.phone = None
        self.email = None
        self.rel = None
        self.org = None
        self.loc = None
        self.set_attributes(name, phone, email, rel, org, loc)

    def set_attributes(self, name, phone, email, rel="", org="", loc=""):
        """
        Sets the attributes of a contact.
        If the name or phone number is empty, it raises a ValueError.
        :param name:
        :param phone:
        :param email:
        :param rel:
        :param org:
        :param loc:
        :return:
        """
        if not name or not phone:
            raise ValueError("Please input name and phone!")
        self.name = name
        self.phone = phone
        self.email = email
        self.rel = rel
        self.org = org
        self.loc = loc

    def __str__(self):
        """
        Returns a string representation of a contact.
        :return:
        """
        string = f"Name: {self.name}\nPhone: {self.phone}"
        if self.email:
            string += "\nEmail: " + self.email
        if self.rel:
            string += "\nRelationship Type: " + self.rel
        if self.org:
            string += "\nOrganization: " + self.org
        if self.loc:
            string += "\nLocation: " + self.loc
        return string

    def to_dict(self):
        """
        Returns a dictionary representation of a contact.
        :return:
        """
        return {
            "name": self.name,
            "phone": self.phone,
            "email": self.email,
            "rel": self.rel,
            "org": self.org,
            "loc": self.loc,
        }


class CMSApp:
    def __init__(self, main_window):
        """
        Initializes a contact management application.
        :param main_window:
        """
        self.root = main_window
        self.root.title("Contact Management System")
        self.root.resizable(False, False)
        self.root.geometry("800x600")

        self.contacts = []
        self.result_text = None
        self.load_contacts()

        self.create_widgets()

    def load_contacts(self):
        """
        Loads contacts from a file.
        :return:
        """
        try:
            with open(FILE_NAME, "r", encoding="utf-8") as file:
                for line in file:
                    data = json.loads(line)
                    contact = Contact(data["name"], data["phone"], data["email"],
                                      data["rel"], data["org"], data["loc"])
                    self.contacts.append(contact)
        except FileNotFoundError:
            print(f"The file {FILE_NAME} was not found.")
            return []

    def save_contacts(self):
        """
        Saves contacts to a file.
        :return:
        """
        try:
            with open(FILE_NAME, "w", encoding="utf-8") as file:
                for contact in self.contacts:
                    file.write(json.dumps(contact.to_dict()) + "\n")
        except IOError as e:
            print(f"Failed to save contacts to {FILE_NAME}: {e.strerror}")

    def filter_contacts(self, field, keyword, is_fully_match):
        """
        Filters the contacts based on the given field and keyword.
        If the field is None, the keyword will be searched in all fields.
        If the is_fully_match is True, the keyword will be matched exactly.
        If the is_fully_match is False, the keyword will be matched partially.
        The keyword matching is case-insensitive.
        :param field:
        :param keyword:
        :param is_fully_match:
        :return:
        """
        result = []
        if not self.contacts:
            return result
        keyword = keyword.strip().lower()
        # Global search across all fields if 'field' is None
        if field is None:
            for contact in self.contacts:
                contact_dict = contact.to_dict()
                if re.match(f".*{keyword}.*", str(contact_dict).lower()):
                    result.append(contact)
        else:
            # Field-specific search
            for contact in self.contacts:
                contact_dict = contact.to_dict()
                field_value = str(contact_dict[field]).lower()
                if is_fully_match and keyword == field_value \
                        or not is_fully_match and keyword in contact_dict[field]:
                    result.append(contact)
        return result

    def create_widgets(self):
        """
        Creates the widgets of the application.
        :return:
        """
        menu_label = tk.Label(self.root, text="Please Select a Option", font=("Monaco", 16))
        menu_label.pack(padx=20, pady=20)

        button_frame = tk.Frame(root)
        button_frame.pack(padx=10, pady=10)
        list_button = tk.Button(button_frame, text="List All Contacts", command=self.display_contacts, width=16)
        list_button.grid(row=0, column=0)

        add_button = tk.Button(button_frame, text="Add New Contact", command=self.add_contact, width=16)
        add_button.grid(row=0, column=1)

        modify_button = tk.Button(button_frame, text="Modify Contact", command=self.modify_contact, width=16)
        modify_button.grid(row=0, column=2)

        remove_button = tk.Button(button_frame, text="Remove Contact", command=self.remove_contact, width=16)
        remove_button.grid(row=0, column=3)

        rel_search_button = tk.Button(button_frame, text="Search by Relationship", command=self.search_by_rel, width=16)
        rel_search_button.grid(row=1, column=0)

        org_search_button = tk.Button(button_frame, text="Search by Organization", command=self.search_by_org, width=16)
        org_search_button.grid(row=1, column=1)

        loc_search_button = tk.Button(button_frame, text="Search by Location", command=self.search_by_loc, width=16)
        loc_search_button.grid(row=1, column=2)

        fuzzy_search_button = tk.Button(button_frame, text="Fuzzy Search", command=self.fuzzy_search, width=16)
        fuzzy_search_button.grid(row=1, column=3)

        user_manual_button = tk.Button(self.root, text="User Manual", command=self.display_user_manual, width=30)
        user_manual_button.pack(padx=10, pady=10)

        quit_button = tk.Button(self.root, text="Quit", command=self.quit, width=30)
        quit_button.pack(padx=10, pady=10)

        text_label = tk.Label(self.root, text="Info Display", font=("Monaco", 13))
        text_label.pack(padx=20, pady=5)
        self.result_text = tk.Text(self.root, height=25, width=100)
        self.result_text.pack(padx=20, pady=10)

    def display_user_manual(self):
        """
        Displays the user manual.
        """
        user_manual = """
        User Manual for Contact Management System\n
        1. List All Contacts
           View the complete list of your contacts.\n
        2. Add New Contact
           Enter details for a new contact line by line with guidance.\n
        3. Modify Contact
           Update details for an existing contact by entering their name.\n
        4. Remove Contact
           Erase a contact from your list using their name.\n
        5. Search by Relationship (case-insensitive)
           Find contacts by specifying their exact relationship type.\n
        6. Search by Organization (case-insensitive)
           Locate contacts by entering their exact organization name.\n
        7. Search by Location (case-insensitive)
           Search for contacts based on their specific location.\n
        8. Fuzzy Search (case-insensitive)
           Use partial information to search across all contact fields.\n
        9. Quit
           Save all changes and close the program.\n
        Now you can choose the option.
        """
        messagebox.showinfo("User Manual", user_manual)

    def display_contacts(self):
        """
        Shows all contacts in the text box.
        :return:
        """
        self.result_text.delete(1.0, tk.END)
        if len(self.contacts) == 0:
            self.result_text.insert(tk.END, 'No contacts.')
        for contact in self.contacts:
            self.result_text.insert(tk.END, str(contact) + "\n" + "-" * 30 + "\n")

    def add_contact(self):
        """
        Adds a new contact.
        :return:
        """
        add_contact_window = tk.Toplevel(self.root)
        add_contact_window.title("Add Contact")

        add_contact_frame = tk.Frame(add_contact_window)
        add_contact_frame.pack(padx=15, pady=10)

        name_label = tk.Label(add_contact_frame, text="Name(Required):")
        name_label.grid(row=0, column=0)
        name_entry = tk.Entry(add_contact_frame)
        name_entry.grid(row=0, column=1)

        phone_label = tk.Label(add_contact_frame, text="Phone Numbers(Required):")
        phone_label.grid(row=1, column=0)
        phone_entry = tk.Entry(add_contact_frame)
        phone_entry.grid(row=1, column=1)

        email_label = tk.Label(add_contact_frame, text="Email(Optional):")
        email_label.grid(row=2, column=0)
        email_entry = tk.Entry(add_contact_frame)
        email_entry.grid(row=2, column=1)

        rel_label = tk.Label(add_contact_frame, text="Relationship Type(Optional):")
        rel_label.grid(row=3, column=0)
        rel_entry = tk.Entry(add_contact_frame)
        rel_entry.grid(row=3, column=1)

        org_label = tk.Label(add_contact_frame, text="Organization(Optional):")
        org_label.grid(row=4, column=0)
        org_entry = tk.Entry(add_contact_frame)
        org_entry.grid(row=4, column=1)

        loc_label = tk.Label(add_contact_frame, text="Location(Optional):")
        loc_label.grid(row=5, column=0)
        loc_entry = tk.Entry(add_contact_frame)
        loc_entry.grid(row=5, column=1)

        def add_contact_submit():
            """
            Adds a new contact.
            If the name or phone number is empty, it raises a ValueError.
            If the phone number is not a number, it raises a ValueError.
            If the email is not empty, and it is not a valid email address, it raises a ValueError.
            If the name is the same as an existing contact, it asks the user to confirm the modification.
            :return:
            """
            if name_entry.get() == '' or phone_entry.get() == '':
                messagebox.showinfo("Failed",
                                    "Error: Both 'Name' and 'Phone Number' are required fields.")
                return
            if not phone_entry.get().isdigit():
                messagebox.showinfo("Failed",
                                    "Invalid phone number. It should only contain digits.")
                return
            if email_entry.get() != '' and not re.match(
                    r'^[a-zA-Z0-9.-_]+@[a-zA-Z0-9.-_]+\.[a-zA-Z]+$', email_entry.get()):
                messagebox.showinfo("Failed",
                                    "Invalid email. Please enter a valid email address\n"
                                    "\t\t\t   E.g.[char.-_digit]@[char.-_digit].[char]")
                return

            same_name_contacts = self.filter_contacts("name", name_entry.get(), True)
            new_contact = Contact(name_entry.get(), phone_entry.get(), email_entry.get(),
                                  rel_entry.get(), org_entry.get(), loc_entry.get())
            if len(same_name_contacts) > 0:
                contact = same_name_contacts[0]
                result = messagebox.askquestion("Confirmation",
                                                "You have the same name contact in your contacts.\n\n"
                                                + '\n' + '-' * 30
                                                + "\nOld Contact:\n"
                                                + "\n".join("\t" + line for line in str(contact).splitlines())
                                                + '\n' + '-' * 30
                                                + '\nNew Contact:\n'
                                                + "\n".join("\t" + line for line in str(new_contact).splitlines())
                                                + '\n' + '-' * 30
                                                + "\n\nWould you want to modify?\n\n"
                                                )
                if result == "yes":
                    contact.set_attributes(name_entry.get(), phone_entry.get(), email_entry.get(),
                                           rel_entry.get(), org_entry.get(), loc_entry.get())
                    self.save_contacts()
                    add_contact_window.destroy()
            else:
                self.contacts.append(new_contact)
                self.save_contacts()
                messagebox.showinfo("Success", "Contact added successfully.")
                add_contact_window.destroy()

        submit_button = tk.Button(add_contact_window, text="Submit", command=add_contact_submit, width=10)
        submit_button.pack(pady=5)

    def modify_contact(self):
        """
        Modifies an existing contact.
        If the name or phone number is empty, it raises a ValueError.
        If the phone number is not a number, it raises a ValueError.
        If the email is not empty, and it is not a valid email address, it raises a ValueError.
        If the name is the same as an existing contact, it asks the user to confirm the modification.
        :return:
        """
        find_contact_windows = tk.Toplevel(self.root)
        name_label = tk.Label(find_contact_windows, text="Name:")
        name_label.grid(row=0, column=0)
        f_name_entry = tk.Entry(find_contact_windows)
        f_name_entry.grid(row=0, column=1)

        def modify_contact_submit():
            if f_name_entry.get() == '':
                messagebox.showinfo("Failed", "Error: 'Name' is required fields.")
                return
            same_name_contacts = self.filter_contacts("name", f_name_entry.get(), True)
            find_contact_windows.destroy()
            if len(same_name_contacts) == 0:
                messagebox.showinfo("Failed", "Can not find this contact!")
                return
            contact = same_name_contacts[0]
            contact_dict = contact.to_dict()

            modify_contact_windows = tk.Toplevel(self.root)
            modify_contact_windows.title("Modify Contact")

            modify_contact_frame = tk.Frame(modify_contact_windows)
            modify_contact_frame.pack(padx=15, pady=10)

            name_label = tk.Label(modify_contact_frame, text="Name(Required):")
            name_label.grid(row=0, column=0)
            name_entry = tk.Entry(modify_contact_frame)
            name_entry.grid(row=0, column=1)
            name_entry.insert(tk.END, contact_dict['name'])

            phone_label = tk.Label(modify_contact_frame, text="Phone Numbers(Required):")
            phone_label.grid(row=1, column=0)
            phone_entry = tk.Entry(modify_contact_frame)
            phone_entry.grid(row=1, column=1)
            phone_entry.insert(tk.END, contact_dict['phone'])

            email_label = tk.Label(modify_contact_frame, text="Email(Optional):")
            email_label.grid(row=2, column=0)
            email_entry = tk.Entry(modify_contact_frame)
            email_entry.grid(row=2, column=1)
            email_entry.insert(tk.END, contact_dict['email'])

            rel_label = tk.Label(modify_contact_frame, text="Relationship Type(Optional):")
            rel_label.grid(row=3, column=0)
            rel_entry = tk.Entry(modify_contact_frame)
            rel_entry.grid(row=3, column=1)
            rel_entry.insert(tk.END, contact_dict['rel'])

            org_label = tk.Label(modify_contact_frame, text="Organization(Optional):")
            org_label.grid(row=4, column=0)
            org_entry = tk.Entry(modify_contact_frame)
            org_entry.grid(row=4, column=1)
            org_entry.insert(tk.END, contact_dict['org'])

            loc_label = tk.Label(modify_contact_frame, text="Location(Optional):")
            loc_label.grid(row=5, column=0)
            loc_entry = tk.Entry(modify_contact_frame)
            loc_entry.grid(row=5, column=1)
            loc_entry.insert(tk.END, contact_dict['loc'])

            def modify_contact_submit_press():
                if name_entry.get().strip() == '' or phone_entry.get().strip() == '':
                    messagebox.showinfo("Failed",
                                        "Error: Both 'Name' and 'Phone Number' are required fields.")
                    return
                if not phone_entry.get().isdigit():
                    messagebox.showinfo("Failed",
                                        "Invalid phone number. It should only contain digits.")
                    return
                if email_entry.get() != '' and not re.match(
                        r'^[a-zA-Z0-9.-_]+@[a-zA-Z0-9.-_]+\.[a-zA-Z]+$', email_entry.get()):
                    messagebox.showinfo("Failed",
                                        "Invalid email. Please enter a valid email address\n"
                                        "\t\t\t   E.g.[char.-_digit]@[char.-_digit].[char]")
                    return

                contact.set_attributes(name_entry.get(), phone_entry.get(), email_entry.get(),
                                       rel_entry.get(), org_entry.get(), loc_entry.get())
                self.save_contacts()
                messagebox.showinfo("Success", "Contact modified successfully.")
                modify_contact_windows.destroy()

            submit_button = tk.Button(modify_contact_windows, text="Modify", command=modify_contact_submit_press, width=10)
            submit_button.pack(pady=5)

        find_button = tk.Button(find_contact_windows, text="Search", command=modify_contact_submit, width=10)
        find_button.grid(row=0, column=2)

    def remove_contact(self):
        """
        Removes an existing contact.
        :return:
        """
        find_contact_windows = tk.Toplevel(self.root)
        name_label = tk.Label(find_contact_windows, text="Name:")
        name_label.grid(row=0, column=0)
        f_name_entry = tk.Entry(find_contact_windows)
        f_name_entry.grid(row=0, column=1)

        def remove_contact_submit():
            if f_name_entry.get() == '':
                messagebox.showinfo("Failed", "Error: 'Name' is required field.")
                return
            same_name_contacts = self.filter_contacts("name", f_name_entry.get(), True)
            find_contact_windows.destroy()
            if len(same_name_contacts) == 0:
                messagebox.showinfo("Failed", "Can not find this contact!")
                return
            contact = same_name_contacts[0]
            contact_dict = contact.to_dict()

            modify_contact_windows = tk.Toplevel(self.root)
            modify_contact_windows.title("Remove Contact")

            modify_contact_frame = tk.Frame(modify_contact_windows)
            modify_contact_frame.pack(padx=15, pady=10)

            name_label = tk.Label(modify_contact_frame, text="Name:")
            name_label.grid(row=0, column=0)
            name_entry = tk.Entry(modify_contact_frame)
            name_entry.grid(row=0, column=1)
            name_entry.insert(tk.END, contact_dict['name'])
            name_entry.configure(state="readonly")

            phone_label = tk.Label(modify_contact_frame, text="Phone Numbers:")
            phone_label.grid(row=1, column=0)
            phone_entry = tk.Entry(modify_contact_frame)
            phone_entry.grid(row=1, column=1)
            phone_entry.insert(tk.END, contact_dict['phone'])
            phone_entry.configure(state="readonly")

            email_label = tk.Label(modify_contact_frame, text="Email:")
            email_label.grid(row=2, column=0)
            email_entry = tk.Entry(modify_contact_frame)
            email_entry.grid(row=2, column=1)
            email_entry.insert(tk.END, contact_dict['email'])
            email_entry.configure(state="readonly")

            rel_label = tk.Label(modify_contact_frame, text="Relationship Type:")
            rel_label.grid(row=3, column=0)
            rel_entry = tk.Entry(modify_contact_frame)
            rel_entry.grid(row=3, column=1)
            rel_entry.insert(tk.END, contact_dict['rel'])
            rel_entry.configure(state="readonly")

            org_label = tk.Label(modify_contact_frame, text="Organization:")
            org_label.grid(row=4, column=0)
            org_entry = tk.Entry(modify_contact_frame)
            org_entry.grid(row=4, column=1)
            org_entry.insert(tk.END, contact_dict['org'])
            org_entry.configure(state="readonly")

            loc_label = tk.Label(modify_contact_frame, text="Location:")
            loc_label.grid(row=5, column=0)
            loc_entry = tk.Entry(modify_contact_frame)
            loc_entry.grid(row=5, column=1)
            loc_entry.insert(tk.END, contact_dict['loc'])
            loc_entry.configure(state="readonly")

            def remove_contact_submit_press():
                self.contacts.remove(contact)
                self.save_contacts()
                messagebox.showinfo("Success", "Contact removed successfully.")
                modify_contact_windows.destroy()

            submit_button = tk.Button(modify_contact_windows, text="Remove", command=remove_contact_submit_press, width=10)
            submit_button.pack(pady=5, padx=5)

        find_button = tk.Button(find_contact_windows, text="Search", command=remove_contact_submit, width=10)
        find_button.grid(row=0, column=2)

    def search_result_window(self, key, word):
        """
        Shows the search result in a new window.
        :param key:
        :param word:
        :return:
        """
        same_name_contacts = self.filter_contacts(key, word, True)
        if len(same_name_contacts) == 0:
            messagebox.showinfo("Failed", "Can not find this contact!")
            return
        contact = same_name_contacts[0]
        contact_dict = contact.to_dict()

        search_result_windows = tk.Toplevel(self.root)
        search_result_windows.title("Search Contact")

        search_result_frame = tk.Frame(search_result_windows)
        search_result_frame.pack(padx=15, pady=10)

        name_label = tk.Label(search_result_frame, text="Name:")
        name_label.grid(row=0, column=0)
        name_entry = tk.Entry(search_result_frame)
        name_entry.grid(row=0, column=1)
        name_entry.insert(tk.END, contact_dict['name'])
        name_entry.configure(state="readonly")

        phone_label = tk.Label(search_result_frame, text="Phone Numbers:")
        phone_label.grid(row=1, column=0)
        phone_entry = tk.Entry(search_result_frame)
        phone_entry.grid(row=1, column=1)
        phone_entry.insert(tk.END, contact_dict['phone'])
        phone_entry.configure(state="readonly")

        email_label = tk.Label(search_result_frame, text="Email:")
        email_label.grid(row=2, column=0)
        email_entry = tk.Entry(search_result_frame)
        email_entry.grid(row=2, column=1)
        email_entry.insert(tk.END, contact_dict['email'])
        email_entry.configure(state="readonly")

        rel_label = tk.Label(search_result_frame, text="Relationship Type:")
        rel_label.grid(row=3, column=0)
        rel_entry = tk.Entry(search_result_frame)
        rel_entry.grid(row=3, column=1)
        rel_entry.insert(tk.END, contact_dict['rel'])
        rel_entry.configure(state="readonly")

        org_label = tk.Label(search_result_frame, text="Organization:")
        org_label.grid(row=4, column=0)
        org_entry = tk.Entry(search_result_frame)
        org_entry.grid(row=4, column=1)
        org_entry.insert(tk.END, contact_dict['org'])
        org_entry.configure(state="readonly")

        loc_label = tk.Label(search_result_frame, text="Location:")
        loc_label.grid(row=5, column=0)
        loc_entry = tk.Entry(search_result_frame)
        loc_entry.grid(row=5, column=1)
        loc_entry.insert(tk.END, contact_dict['loc'])
        loc_entry.configure(state="readonly")

        def search_result_window_submit():
            search_result_windows.destroy()

        submit_button = tk.Button(search_result_windows, text="Close", command=search_result_window_submit, width=10)
        submit_button.pack(pady=5)

    def search_by_rel(self):
        """
        Searches a contact by relationship type.
        :return:
        """
        find_contact_windows = tk.Toplevel(self.root)
        rel_label = tk.Label(find_contact_windows, text="Relationship Type:")
        rel_label.grid(row=0, column=0)
        f_rel_entry = tk.Entry(find_contact_windows)
        f_rel_entry.grid(row=0, column=1)

        def search_by_rel_contact_submit():
            if f_rel_entry.get() == '':
                messagebox.showinfo("Failed", "Error: 'Relationship Type' is required field.")
                return
            self.search_result_window('rel', f_rel_entry.get())
            find_contact_windows.destroy()

        find_button = tk.Button(find_contact_windows, text="Search", command=search_by_rel_contact_submit, width=10)
        find_button.grid(row=0, column=2)

    def search_by_org(self):
        """
        Searches a contact by organization.
        :return:
        """
        find_contact_windows = tk.Toplevel(self.root)
        org_label = tk.Label(find_contact_windows, text="Organization:")
        org_label.grid(row=0, column=0)
        f_org_entry = tk.Entry(find_contact_windows)
        f_org_entry.grid(row=0, column=1)

        def search_by_org_contact_submit():
            if f_org_entry.get() == '':
                messagebox.showinfo("Failed", "Error: 'Organization' is required field.")
                return
            self.search_result_window('org', f_org_entry.get())
            find_contact_windows.destroy()

        find_button = tk.Button(find_contact_windows, text="Search", command=search_by_org_contact_submit, width=10)
        find_button.grid(row=0, column=2)

    def search_by_loc(self):
        """
        Searches a contact by location.
        :return:
        """
        find_contact_windows = tk.Toplevel(self.root)
        loc_label = tk.Label(find_contact_windows, text="Location:")
        loc_label.grid(row=0, column=0)
        f_loc_entry = tk.Entry(find_contact_windows)
        f_loc_entry.grid(row=0, column=1)

        def search_by_loc_contact_submit():
            if f_loc_entry.get() == '':
                messagebox.showinfo("Failed", "Error: 'Location' is required field.")
                return
            self.search_result_window('loc', f_loc_entry.get())
            find_contact_windows.destroy()

        find_button = tk.Button(find_contact_windows, text="Search", command=search_by_loc_contact_submit, width=10)
        find_button.grid(row=0, column=2)

    def fuzzy_search(self):
        """
        Searches a contact by keyword.
        The keyword will be searched in all fields.
        The keyword matching is case-insensitive.
        :return:
        """
        find_contact_windows = tk.Toplevel(self.root)
        loc_label = tk.Label(find_contact_windows, text="Key word:")
        loc_label.grid(row=0, column=0)
        f_loc_entry = tk.Entry(find_contact_windows)
        f_loc_entry.grid(row=0, column=1)

        def search_by_loc_contact_submit():
            if f_loc_entry.get() == '':
                messagebox.showinfo("Failed", "Error: 'Key word' is required field.")
                return
            self.search_result_window(None, f_loc_entry.get())
            find_contact_windows.destroy()

        find_button = tk.Button(find_contact_windows, text="Search", command=search_by_loc_contact_submit, width=10)
        find_button.grid(row=0, column=2)

    def quit(self):
        """
        Quits the application.
        :return:
        """
        self.save_contacts()
        self.root.destroy()

    def run(self):
        """
        Runs the application.
        :return:
        """
        self.root.mainloop()


if __name__ == '__main__':
    root = tk.Tk()
    app = CMSApp(main_window=root)
    app.run()
